package com.aj.shared.db

import kotlin.ByteArray
import kotlin.Long
import kotlin.String

public data class ImageChunkEntity(
  public val id: String,
  public val fileId: String,
  public val chunkIndex: Long,
  public val totalChunks: Long,
  public val chunkData: ByteArray,
  public val status: String,
  public val uploadUrl: String,
)
