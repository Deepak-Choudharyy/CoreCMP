package com.aj.shared.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.ByteArray
import kotlin.Long
import kotlin.String

public class DatabaseQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> getAllApiQueue(mapper: (
    id: Long,
    endpoint: String,
    method: String,
    bodyPayload: String?,
    headers: String?,
    createdAt: Long,
  ) -> T): Query<T> = Query(-604_829_290, arrayOf("apiQueueEntity"), driver, "Database.sq",
      "getAllApiQueue",
      "SELECT apiQueueEntity.id, apiQueueEntity.endpoint, apiQueueEntity.method, apiQueueEntity.bodyPayload, apiQueueEntity.headers, apiQueueEntity.createdAt FROM apiQueueEntity ORDER BY createdAt ASC") {
      cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getLong(5)!!
    )
  }

  public fun getAllApiQueue(): Query<ApiQueueEntity> = getAllApiQueue { id, endpoint, method,
      bodyPayload, headers, createdAt ->
    ApiQueueEntity(
      id,
      endpoint,
      method,
      bodyPayload,
      headers,
      createdAt
    )
  }

  public fun <T : Any> getChunksByFileId(fileId: String, mapper: (
    id: String,
    fileId: String,
    chunkIndex: Long,
    totalChunks: Long,
    chunkData: ByteArray,
    status: String,
    uploadUrl: String,
  ) -> T): Query<T> = GetChunksByFileIdQuery(fileId) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getBytes(4)!!,
      cursor.getString(5)!!,
      cursor.getString(6)!!
    )
  }

  public fun getChunksByFileId(fileId: String): Query<ImageChunkEntity> =
      getChunksByFileId(fileId) { id, fileId_, chunkIndex, totalChunks, chunkData, status,
      uploadUrl ->
    ImageChunkEntity(
      id,
      fileId_,
      chunkIndex,
      totalChunks,
      chunkData,
      status,
      uploadUrl
    )
  }

  public fun <T : Any> getPendingChunks(mapper: (
    id: String,
    fileId: String,
    chunkIndex: Long,
    totalChunks: Long,
    chunkData: ByteArray,
    status: String,
    uploadUrl: String,
  ) -> T): Query<T> = Query(790_940_251, arrayOf("imageChunkEntity"), driver, "Database.sq",
      "getPendingChunks",
      "SELECT imageChunkEntity.id, imageChunkEntity.fileId, imageChunkEntity.chunkIndex, imageChunkEntity.totalChunks, imageChunkEntity.chunkData, imageChunkEntity.status, imageChunkEntity.uploadUrl FROM imageChunkEntity WHERE status = 'PENDING' ORDER BY fileId, chunkIndex ASC") {
      cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getBytes(4)!!,
      cursor.getString(5)!!,
      cursor.getString(6)!!
    )
  }

  public fun getPendingChunks(): Query<ImageChunkEntity> = getPendingChunks { id, fileId,
      chunkIndex, totalChunks, chunkData, status, uploadUrl ->
    ImageChunkEntity(
      id,
      fileId,
      chunkIndex,
      totalChunks,
      chunkData,
      status,
      uploadUrl
    )
  }

  public fun insertApiQueue(
    endpoint: String,
    method: String,
    bodyPayload: String?,
    headers: String?,
    createdAt: Long,
  ) {
    driver.execute(1_184_723_940, """
        |INSERT INTO apiQueueEntity(endpoint, method, bodyPayload, headers, createdAt)
        |VALUES (?, ?, ?, ?, ?)
        """.trimMargin(), 5) {
          bindString(0, endpoint)
          bindString(1, method)
          bindString(2, bodyPayload)
          bindString(3, headers)
          bindLong(4, createdAt)
        }
    notifyQueries(1_184_723_940) { emit ->
      emit("apiQueueEntity")
    }
  }

  public fun deleteApiQueueById(id: Long) {
    driver.execute(60_266_952, """DELETE FROM apiQueueEntity WHERE id = ?""", 1) {
          bindLong(0, id)
        }
    notifyQueries(60_266_952) { emit ->
      emit("apiQueueEntity")
    }
  }

  public fun insertImageChunk(
    id: String,
    fileId: String,
    chunkIndex: Long,
    totalChunks: Long,
    chunkData: ByteArray,
    status: String,
    uploadUrl: String,
  ) {
    driver.execute(706_457_439, """
        |INSERT INTO imageChunkEntity(id, fileId, chunkIndex, totalChunks, chunkData, status, uploadUrl)
        |VALUES (?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 7) {
          bindString(0, id)
          bindString(1, fileId)
          bindLong(2, chunkIndex)
          bindLong(3, totalChunks)
          bindBytes(4, chunkData)
          bindString(5, status)
          bindString(6, uploadUrl)
        }
    notifyQueries(706_457_439) { emit ->
      emit("imageChunkEntity")
    }
  }

  public fun updateChunkStatus(status: String, id: String) {
    driver.execute(-976_755_518, """UPDATE imageChunkEntity SET status = ? WHERE id = ?""", 2) {
          bindString(0, status)
          bindString(1, id)
        }
    notifyQueries(-976_755_518) { emit ->
      emit("imageChunkEntity")
    }
  }

  public fun deleteChunksByFileId(fileId: String) {
    driver.execute(217_702_195, """DELETE FROM imageChunkEntity WHERE fileId = ?""", 1) {
          bindString(0, fileId)
        }
    notifyQueries(217_702_195) { emit ->
      emit("imageChunkEntity")
    }
  }

  private inner class GetChunksByFileIdQuery<out T : Any>(
    public val fileId: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("imageChunkEntity", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("imageChunkEntity", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> =
        driver.executeQuery(-943_454_666,
        """SELECT imageChunkEntity.id, imageChunkEntity.fileId, imageChunkEntity.chunkIndex, imageChunkEntity.totalChunks, imageChunkEntity.chunkData, imageChunkEntity.status, imageChunkEntity.uploadUrl FROM imageChunkEntity WHERE fileId = ? ORDER BY chunkIndex ASC""",
        mapper, 1) {
      bindString(0, fileId)
    }

    override fun toString(): String = "Database.sq:getChunksByFileId"
  }
}
