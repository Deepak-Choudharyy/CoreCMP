@file:OptIn(InternalResourceApi::class)

package com.corecmp.shared.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.corecmp.shared.generated.resources/"

@delegate:ResourceContentHash(2_006_814_001)
public val Res.drawable.ic_camera: DrawableResource by lazy {
      DrawableResource("drawable:ic_camera", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_camera.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-866_360_403)
public val Res.drawable.ic_documents: DrawableResource by lazy {
      DrawableResource("drawable:ic_documents", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_documents.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_039_806_888)
public val Res.drawable.ic_photos: DrawableResource by lazy {
      DrawableResource("drawable:ic_photos", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_photos.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("ic_camera", Res.drawable.ic_camera)
  map.put("ic_documents", Res.drawable.ic_documents)
  map.put("ic_photos", Res.drawable.ic_photos)
}
